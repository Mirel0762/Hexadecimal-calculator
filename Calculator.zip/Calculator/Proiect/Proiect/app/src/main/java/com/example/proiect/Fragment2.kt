package com.example.proiect

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.cursoradapter.widget.SimpleCursorAdapter


class Fragment2 : Fragment() {

    private lateinit var listView: ListView
    private var dataList: ArrayList<String> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_2, container, false)
    }

    @SuppressLint("Range")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        listView = view.findViewById(R.id.rezultat)

        val dbHelper = BazaDate(requireContext())
        val db = dbHelper.readableDatabase

        // interogare baza de date
        val cursor = db.rawQuery("SELECT * FROM tabela2", null)

        if (cursor.moveToFirst()) {
            do {
                val baza = cursor.getString(cursor.getColumnIndex("baza"))
                val numar1 = cursor.getString(cursor.getColumnIndex("numar1"))
                val numar2 = cursor.getString(cursor.getColumnIndex("numar2"))
                val rez = cursor.getString(cursor.getColumnIndex("rez"))

                // adauga datele intr-un ArrayList
                dataList.add("$baza")
                dataList.add("$numar1")
                dataList.add("$numar2")
                dataList.add("$rez")
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()

        // creaza adapter pentru ListView
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, dataList)

        // seteaza adapterul ListView
        listView.adapter = adapter

        listView.setOnItemClickListener { parent, _, position, _ ->
            val selectedItem = parent.getItemAtPosition(position) as String
            if (selectedItem == "select baza 10" || selectedItem == "select baza 16") {
                return@setOnItemClickListener
            }
            val separatori = arrayOf("+","-","=")
            val numarsel = selectedItem.split(*separatori).first()
            (activity as MainActivity).trimitemaLaFragmentul1(numarsel)
       }
    }

    }


