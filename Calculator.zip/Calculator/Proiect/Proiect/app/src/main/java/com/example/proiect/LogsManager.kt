package com.example.proiect

object LogsManager {
    lateinit var logs: ArrayList<String>
}