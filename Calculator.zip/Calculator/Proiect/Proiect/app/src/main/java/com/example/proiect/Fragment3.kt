package com.example.proiect

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.icu.util.Calendar
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment


class Fragment3 : Fragment() {

    private lateinit var listView: ListView
    private var dataList: ArrayList<String> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_3, container, false)
    }
    @SuppressLint("Range")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        listView = view.findViewById(R.id.istoric)

        val dbHelper = BazaDate(requireContext())
        val db = dbHelper.readableDatabase

        // interogare baza de date
        val cursor = db.rawQuery("SELECT * FROM tabela2", null)

        if (cursor.moveToFirst()) {
            do {
                val baza = cursor.getString(cursor.getColumnIndex("baza"))
                val numar1 = cursor.getString(cursor.getColumnIndex("numar1"))
                val numar2 = cursor.getString(cursor.getColumnIndex("numar2"))
                val rez = cursor.getString(cursor.getColumnIndex("rez"))

                // adauga datele intr-un ArrayList
                dataList.add(baza)
                dataList.add(numar1)
                dataList.add(numar2)
                dataList.add(rez)
            } while (cursor.moveToNext())
        }
        cursor.close()


        // creaza adapter pentru ListView
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, dataList)

        // seteaza adapterul ListView
        listView.adapter = adapter

        //trimitere mail
        val email= view.findViewById<AutoCompleteTextView>(R.id.email_text)
        val subiect=view.findViewById<EditText>(R.id.subiect_text)
        val butonSend=view.findViewById<Button>(R.id.send_button)
        butonSend.setOnClickListener {

            val emailtext= email.text.toString().trim()
            val subiecttext=subiect.text.toString().trim()
            // Transformă lista într-un șir de text formatat
            val textlista=dataList.joinToString(separator ="\n")

            trimiteEmail(emailtext, subiecttext, textlista)

            val emailt = email.text.toString()
            val values = ContentValues().apply {
                put("adresa", emailt)
                val currentDateTime = Calendar.getInstance().time.toString() // obțineți data și ora curentă
                put("dataora", currentDateTime)
            }
            val newRowId = db?.insert("tabela3", null, values)

        }


        //obtinere referinta autocomplete
        // Interogarea bazei de date pentru a obține lista de adrese de e-mail
        val emailList = ArrayList<String>()
        val cursor1 = db.rawQuery("SELECT * FROM tabela3", null)
        if (cursor1.moveToFirst()) {
            do {
                val emailvalue = cursor1.getString(cursor1.getColumnIndex("adresa"))
                emailList.add("$emailvalue")
            } while (cursor1.moveToNext())
        }
        cursor1.close()

        // Crearea adaptorului pentru sugestiile de e-mail
        val adapter1 = ArrayAdapter<String>(requireContext(), android.R.layout.simple_dropdown_item_1line, emailList)

       // Setarea adaptorului pentru AutoCompleteTextView
        email.setAdapter(adapter1)

    }

    private fun trimiteEmail(email: String, subiect: String, textlista: String) {
        val emailIntent = Intent(Intent.ACTION_SEND)
        emailIntent.data= Uri.parse("malito:")
        emailIntent.type = "plain/text"
        emailIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subiect)
        emailIntent.putExtra(Intent.EXTRA_TEXT, textlista)

        try{
             startActivity(Intent.createChooser(emailIntent, "Alege o aplicatie de mail"))
        }
        catch (e: Exception){
            Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()
        }
    }

}