package com.example.proiect


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.fragment.app.Fragment



class Fragment4 : Fragment() {



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
         val view = inflater.inflate(R.layout.fragment_4, container, false)
       // Init the list with the data and enable the scrolling container.
        val logsList = view.findViewById<ListView>(R.id.log)
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, LogsManager.logs)
        logsList.adapter = adapter
        logsList.isScrollContainer = true

        // Auto scroll to the last operation (the end).
        val lastItem = logsList.count - 1
        logsList.setSelection(lastItem)

        return view
    }

}
