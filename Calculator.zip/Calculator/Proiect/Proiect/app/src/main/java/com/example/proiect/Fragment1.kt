@file:Suppress("DEPRECATION")

package com.example.proiect

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proiect.databinding.Fragment1Binding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.FileWriter
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.cert.X509Certificate
import java.util.*
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager


// This class is a helper class in order to avoid certificate validation.
@SuppressLint("CustomX509TrustManager")
class TrustAllCerts : X509TrustManager {
    override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) = Unit
    override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) = Unit
    override fun getAcceptedIssuers() = arrayOf<X509Certificate>()
}

class Fragment1 : Fragment() {
    var valoarePrimitaDinFragment2: String? = null
    private lateinit var binding: Fragment1Binding
    private var currentBase = 10 // începeți cu baza 10

    lateinit var logs: ArrayList<String>

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (!TextUtils.isEmpty(valoarePrimitaDinFragment2)) {
            binding.numar2.text = valoarePrimitaDinFragment2
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = Fragment1Binding.inflate(inflater, container, false)

        logs= ArrayList()
        //baza de date
        val dbHelper = BazaDate(requireActivity())
        val db = dbHelper.writableDatabase

        //valoarea 0 la inceput
        binding.numar1.text = "0"
        //tastatura dezactivata
        binding.numar1.keyListener = null
        binding.numar2.keyListener = null
        binding.semn.keyListener = null


//      //se incepe aplicatia cu acces la toata tastatura(baza16)
        val buttonsToDisable = listOf(
            binding.butA,
            binding.butB,
            binding.butC,
            binding.butD,
            binding.butE,
            binding.butF
        )
        for (button in buttonsToDisable) {
            button.isEnabled = true
        }
        binding.buton1016.setBackgroundColor(
            ContextCompat.getColor(
                binding.buton1016.context,
                R.color.enabled_color
            )
        )
        currentBase = 16 //setează baza la 16

        //
        //am adaugat click listener pentru butonul =
        binding.ButonOk.setOnClickListener {
            if (binding.numar1.text.isNotEmpty() && binding.semn.text.isNotEmpty() && binding.numar2.text.isNotEmpty()) {
                val nr1 = binding.numar1.text.toString()
                val nr2 = binding.numar2.text.toString()
                val input = binding.semn.text.toString()
                val operator = input.firstOrNull() ?: ' '
                val decimal1 = if (currentBase == 16 && nr1.startsWith("0x")) {
                    Integer.parseInt(nr1.substring(2), 16)
                } else {
                    nr1.toInt(currentBase)
                }
                val decimal2 = if (currentBase == 16 && nr2.startsWith("0x")) {
                    Integer.parseInt(nr2.substring(2), 16)
                } else {
                    nr2.toInt(currentBase)
                }
                val result = calculate(
                    decimal1.toString(currentBase),
                    decimal2.toString(currentBase),
                    operator,
                    currentBase
                )

                binding.rez.text = "=$result"
                binding.ButonOk.isEnabled = true

                val values = ContentValues().apply {
                    put("operatie", binding.semn.text.toString())
                    put("operand1", binding.numar1.text.toString())
                    put("operand2", binding.numar2.text.toString())
                    put("bazanumeratie", "select baza " + currentBase)
                    put("rezultat", result)
                    put("dataora", System.currentTimeMillis())
                }
                val newRowId = db?.insert("tabela1", null, values)

                val values1 = ContentValues().apply {
                    put("numar1", binding.numar1.text.toString() + binding.semn.text.toString())
                    put("numar2", binding.numar2.text.toString() + "=")
                    put(
                        "rez",
                        result + "=" + binding.numar1.text.toString() + binding.semn.text.toString() + binding.numar2.text.toString()
                    )
                    put("baza", "select baza " + currentBase)
                }
                val newRowId2 = db?.insert("tabela2", null, values1)
//                db.delete("tabela1", null, null)
//                db.delete("tabela2", null, null)


                // Connect to server.
                sendAndVerifyOperation(currentBase, binding.numar1.text.toString(), binding.semn.text.toString(), binding.numar2.text.toString(),result)

            } else binding.ButonOk.isEnabled = false
            }

        binding.plus.setOnClickListener {
            if (binding.numar1.text.toString()
                    .isNotEmpty() && binding.numar1.text.toString() != "0"
            ) {
                binding.semn.text = binding.semn.text.dropLast(1)
                binding.semn.text = binding.semn.text.toString() + "+"

            } else {
                val primulnr = binding.numar2.text.toString()
                binding.numar1.text = primulnr
                binding.numar2.text = "0"
                binding.rez.text = ""
                binding.semn.text = binding.semn.text.toString() + "+"
            }
        }
        binding.minus.setOnClickListener {
            if (binding.numar1.text.toString()
                    .isNotEmpty() && binding.numar1.text.toString() != "0"
            ) {
                binding.semn.text = binding.semn.text.dropLast(1)
                binding.semn.text = binding.semn.text.toString() + "-"

            } else {
                val primulnr = binding.numar2.text.toString()
                binding.numar1.text = primulnr
                binding.numar2.text = "0"
                binding.rez.text = ""
                binding.semn.text = binding.semn.text.toString() + "-"
            }
        }
        binding.ori.setOnClickListener {
            if (binding.numar1.text.toString()
                    .isNotEmpty() && binding.numar1.text.toString() != "0"
            ) {
                binding.semn.text = binding.semn.text.dropLast(1)
                binding.semn.text = binding.semn.text.toString() + "*"

            } else {
                val primulnr = binding.numar2.text.toString()
                binding.numar1.text = primulnr
                binding.numar2.text = "0"
                binding.rez.text = ""
                binding.semn.text = binding.semn.text.toString() + "*"
            }
        }

        binding.buton1016.setOnClickListener {
            currentBase = if (currentBase == 10) {
                butoane(binding.buton1016, buttonsToDisable, true)
                16
            } else {
                butoane(binding.buton1016, buttonsToDisable, false)
                10
            }
        }
        //stergere un singur caracter pentru butonul back
        binding.back.setOnClickListener {
            val lungime = binding.numar2.length()
            if (binding.numar2.text.isNotEmpty()) {
                binding.numar2.text = binding.numar2.text.subSequence(0, lungime - 1)
            }
        }

        //Listner ca sa adauge cifra/litera apasata
        binding.but0.setOnClickListener { actiuneNumar("0") }
        binding.but1.setOnClickListener { actiuneNumar("1") }
        binding.but2.setOnClickListener { actiuneNumar("2") }
        binding.but3.setOnClickListener { actiuneNumar("3") }
        binding.but4.setOnClickListener { actiuneNumar("4") }
        binding.but5.setOnClickListener { actiuneNumar("5") }
        binding.but6.setOnClickListener { actiuneNumar("6") }
        binding.but7.setOnClickListener { actiuneNumar("7") }
        binding.but8.setOnClickListener { actiuneNumar("8") }
        binding.but9.setOnClickListener { actiuneNumar("9") }
        binding.butA.setOnClickListener { actiuneNumar("A") }
        binding.butB.setOnClickListener { actiuneNumar("B") }
        binding.butC.setOnClickListener { actiuneNumar("C") }
        binding.butD.setOnClickListener { actiuneNumar("D") }
        binding.butE.setOnClickListener { actiuneNumar("E") }
        binding.butF.setOnClickListener { actiuneNumar("F") }

        return binding.root
    }

    //functii
    fun actiuneNumar(numar: String) {
        if (binding.numar2.text.toString() == "0") {
            binding.numar2.text = ""
        }
        binding.numar2.append(numar)

        if (binding.numar1.text.toString().isNotEmpty() && binding.rez.text.toString()
                .isNotEmpty()
        ) {
            binding.rez.text = ""
            binding.numar1.text = ""
            binding.semn.text = ""
            binding.numar2.text = ""
            binding.numar2.append(numar)
        }
    }

    fun butoane(buton1016: Button, buttonsToDisable: List<Button>, isEnabled: Boolean) {
        for (button in buttonsToDisable) {
            button.isEnabled = isEnabled
        }
        val colorResId = if (isEnabled) R.color.enabled_color else R.color.disabled_color
        buton1016.setBackgroundColor(ContextCompat.getColor(buton1016.context, colorResId))
    }

    //calcul baza 10 sau 16
    fun calculate(nr1: String, nr2: String, operator: Char, base: Int): String {
        val decimal1 = if (base == 16 && nr1.startsWith("0x")) {
            Integer.parseInt(nr1.substring(2), 16)
        } else {
            nr1.toInt(base)
        }

        val decimal2 = if (base == 16 && nr2.startsWith("0x")) {
            Integer.parseInt(nr2.substring(2), 16)
        } else {
            nr2.toInt(base)
        }

        val result = when (operator) {
            '+' -> decimal1 + decimal2
            '-' -> decimal1 - decimal2
            '*' -> decimal1 * decimal2
            else -> throw IllegalArgumentException("Invalid operator")
        }

        return when (base) {
            16 -> Integer.toHexString(result).uppercase(Locale.getDefault())
            else -> result.toString(base)
        }
    }

    // Server connection.
    private fun sendDataToServer(operation: String, result: String) {
        // Format the current date and time
        val dateFormat = java.text.SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.getDefault())
        val dateTime = dateFormat.format(Date())

        // Encode the operation and result for the URL
        val encodedOperation = URLEncoder.encode(operation, "UTF-8")
        val encodedResult = URLEncoder.encode(result, "UTF-8")

        // Construct the URL
        val url = "https://idp.upg-ploiesti.ro/z/zdemo9/calc?q=$encodedOperation%20$encodedResult"

        try {
            // Open a connection to the server and set the request method
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"

            // Connect to the server and read the response
            connection.connect()
            val reader = BufferedReader(InputStreamReader(connection.inputStream))
            val response = reader.readText()

            // Log the result
            logs.add("$dateTime Operation send: $operation $result")
            logs.add("$dateTime Result received: $response")

        } catch (e: java.lang.Exception) {
            // Log the error
            logs.add("$dateTime Connect server: failed")
            e.printStackTrace()
        }
    }

    private fun sendAndVerifyOperation(base: Int, num1: String, operator: String, num2: String, result: String) {
        val connectivityManager = requireContext().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo

        if (networkInfo == null || !networkInfo.isConnected) {
            Toast.makeText(requireContext(), "No network connection!", Toast.LENGTH_SHORT).show()
            logs.add("${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())}> No network connection, unable to contact server!")
            saveLogsToFile("${
                java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())}> No network connection, unable to contact server!")
            return
        }

        val baseUrl = "https://idp.upg-ploiesti.ro/z/zdemo9/calc"
        val baseOp = if (base == 10) "dec" else "hex"
        val operation = "user21 $baseOp $num1 $operator $num2"
        val encodedOperation = operation.replace("+", "%2B").replace(" ", "%20").replace("*", "%2A")
        val fullUrl = "$baseUrl?q=$encodedOperation"

        val dateFormat = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())

        logs.add("${dateFormat.format(Date())} Connect server: start")
        saveLogsToFile("${dateFormat.format(Date())} Connect server: start")

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Since we don't have access to the server cert. file, we can disable cert verification. Note that this option is not recommended.
                val sslContext = SSLContext.getInstance("SSL")
                sslContext.init(null, arrayOf(TrustAllCerts()), java.security.SecureRandom())

                val client = OkHttpClient.Builder()
                    .sslSocketFactory(sslContext.socketFactory, TrustAllCerts())
                    .hostnameVerifier { _, _ -> true }
                    .build()
                val request = Request.Builder().url(fullUrl).build()

                val response = client.newCall(request).execute()
                val responseCode = response.code

                // Verifies the response, if successful then it validates if the result of the calculator is the same with the result from the server.
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val responseBody = response.body?.string() ?: ""

                    logs.add("${dateFormat.format(Date())} Connect server: success")
                    saveLogsToFile("${dateFormat.format(Date())} Connect server: success")

                    logs.add("${dateFormat.format(Date())} Operation send: $operation")
                    saveLogsToFile("${dateFormat.format(Date())} Operation send: $operation")

                    val responseTrim = responseBody.substringBefore("..........................")
                    val parts = responseTrim.split(" ")
                    val output = parts.takeLast(1)[0].uppercase()

                    var aux: String = ("${dateFormat.format(Date())} Result received: $baseOp $num1 $operator $num2 = $output")

                    logs.add(aux)
                    saveLogsToFile(aux)

                    if (output.trim() == result) {
                        logs.add("                Result correct")
                        saveLogsToFile("                Result correct")
                    } else {
                        logs.add("                Result incorrect")
                        saveLogsToFile("                Result incorrect")
                    }
                } else {
                    logs.add("${dateFormat.format(Date())} Connect server: failed with response code $responseCode")
                    saveLogsToFile("${dateFormat.format(Date())} Connect server: failed with response code $responseCode")
                }
                logs.add("----------Connection closed----------")
                saveLogsToFile("----------Connection closed----------")
                response.close()
            } catch (e: Exception) {
                logs.add("${dateFormat.format(Date())} Connection error: failed with exception ${e.message}")
                saveLogsToFile("${dateFormat.format(Date())} Connection error: failed with exception ${e.message}")
            }
        }
    }
    // Function to append logs to the file.
    private fun saveLogsToFile(data: String) {
        val file = File(requireContext().filesDir, "logs.txt")
        if(!file.exists())
            file.createNewFile()
        val writer = FileWriter(file, true)
        writer.appendLine(data)
        writer.close()
    }
}








