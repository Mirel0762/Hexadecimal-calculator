
package com.example.proiect

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.util.*
import kotlin.collections.ArrayList


@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity(){

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        LogsManager.logs= ArrayList()
        // For logs, we have to read from the file.
        val file = File(applicationContext.filesDir, "logs.txt")
        if(file.exists()) {
            val reader = BufferedReader(FileReader(file))
            val logsString = reader.readText()
            reader.close()
            LogsManager.logs.addAll(logsString.split("\n"))
        }

      // primul fragment sa fie calcul
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, Fragment1())
            .commit()
        }


    //meniu1
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.meniu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.calcul -> {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, Fragment1())
                    .commit()
                true
            }
            R.id.istoric -> {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, Fragment2())
                    .commit()
                true
            }
            R.id.mail -> {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, Fragment3())
                    .commit()
                true
            }
            R.id.log -> {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, Fragment4())
                    .commit()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun trimitemaLaFragmentul1(numar_primit: String){
        val noulFragment1 = Fragment1();
        noulFragment1.valoarePrimitaDinFragment2 = numar_primit;

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, noulFragment1)
            .commit()
    }


}








