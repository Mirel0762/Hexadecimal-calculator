package com.example.proiect

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BazaDate(context: Context): SQLiteOpenHelper(context, DATABASE_NAME,null, DATABASE_VERSION) { //Definim clasa BazaDate care extinde clasa SQLiteOpenHelper și primește un parametru de tip Context în constructor.
    companion object {
        // clasă companion care conține constantele DATABASE_NAME și DATABASE_VERSION.
        const val DATABASE_NAME = "my_database"
        const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(    // metoda onCreate a clasei SQLiteOpenHelper. În această metodă, cream trei tabele (tabela1, tabela2, tabela3) în baza de date utilizând comanda CREATE TABLE.
            "CREATE TABLE tabela1 (" +
                    "operatie TEXT," +
                    "operand1 TEXT," +
                    "operand2 TEXT," +
                    "bazanumeratie TEXT," +
                    "rezultat TEXT,"+
                    "dataora DATETIME DEFAULT CURRENT_TIMESTAMP"+
                    ")"
        )
        db?.execSQL(
            "CREATE TABLE tabela2 (" +
                    "baza TEXT," +
                    "numar1 TEXT," +
                    "numar2 TEXT," +
                    "rez TEXT" +
                    ")"
        )
        db?.execSQL(
            "CREATE TABLE tabela3 (" +
                    "adresa TEXT," +
                    "dataora DATETIME DEFAULT CURRENT_TIMESTAMP" +
                    ")"
        )
    }
    //metoda onUpgrade a clasei SQLiteOpenHelper. Această metodă este apelată atunci când versiunea bazei de date este actualizată. În comentariu, menționăm că aici se poate actualiza schema bazei de date.
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Actualizează schema bazei de date
    }
}
